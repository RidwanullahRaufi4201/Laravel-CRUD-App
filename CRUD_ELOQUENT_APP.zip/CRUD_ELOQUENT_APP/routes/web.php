<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;



Route::get('/',[StudentController::class,'index'])->name('index');
Route::post('/',[StudentController::class,'create'])->name('create');


Route::get('edit/{id}',[StudentController::class,'edit']);
Route::post('edit/{id}',[StudentController::class,'update']);



Route::get('delete/{id}',[StudentController::class,'delete']);