<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD IN USING ELOQUENT</title>
</head>
<body>
    <div class="container-fluid bg-success p-3">
         <div class="row">
            <div class="col-md-12">
                <h5 class="text-center text-white">CRUD IN LARAVEL  USING ELOQUENT</h5>
                <p class="text-center m-2 text-white">Edit Page</p>
            </div>
         </div>
    </div>
      <div class="container">
    
            <div class="row justify-content-center">
                <div class="col-md-8 m-2">
                    <form action="" method="post">
                        @csrf
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">FirstName</label>
                              <input type="text" name="firstname" value="{{$student->firstname}}" class="form-control">
                                  @error('firstname')
                                    <p class=" text-danger">
                                        {{$message}}
                                    </p>
                                  @enderror
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">LastName</label>
                              <input type="text" name="lastname" value="{{$student->lastname}}" class="form-control">
                              @error('lastname')
                                    <p class="text-danger">
                                        {{$message}}
                                    </p>
                                  @enderror
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Username</label>
                              <input type="text" name="username" value="{{$student->username}}" class="form-control">
                              @error('username')
                                    <p class="text-danger">
                                        {{$message}}
                                    </p>
                                  @enderror
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Email</label>
                              <input type="email" name="email" value="{{$student->email}}" class="form-control">
                              @error('email')
                                    <p class="text-danger">
                                        {{$message}}
                                    </p>
                                  @enderror
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Pasword</label>
                              <input type="password" value="{{$student->password}}" name="password" class="form-control">
                              @error('password')
                                    <p class="text-danger">
                                        {{$message}}
                                    </p>
                                  @enderror
                              
                        </div>
                        <div class="form-group mt-2">
                    
                              <input type="submit" name="submit" value="SUBMIT" class="form-control bg-success text-white">
                        </div>
                    
                 
                </div>
               
            </div>
      </div>
</body>
</html>