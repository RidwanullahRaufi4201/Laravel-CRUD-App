<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD USING ELOQUENT</title>
</head>
<body>
    <div class="container-fluid bg-success p-3">
         <div class="row">
            <div class="col-md-12">
                <h5 class="text-center text-white">CRUD IN LARAVEL USING ELOQUENT</h5>
            </div>
         </div>
    </div>
      <div class="container">
    
            <div class="row">
                <div class="col-md-4 m-2">
                    <form action="" method="post">
                        @csrf
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">FirstName</label>
                              <input type="text" name="firstname" class="form-control">
                              @error('firstname')
                                <p class="text-danger">
                                    {{$message}}
                                </p>
                              @enderror
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">LastName</label>
                              <input type="text" name="lastname" class="form-control">
                              @error('lastname')
                                <p class="text-danger">
                                    {{$message}}
                                </p>
                              @enderror
                           
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Username</label>
                              <input type="text" name="username" class="form-control">
                          
                              @error('username')
                                <p class="text-danger">
                                    {{$message}}
                                </p>
                              @enderror
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Email</label>
                              <input type="email" name="email" class="form-control">
                              @error('email')
                                <p class="text-danger">
                                    {{$message}}
                                </p>
                              @enderror
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Pasword</label>
                              <input type="password" name="password" class="form-control">
                              @error('password')
                                <p class="text-danger">
                                    {{$message}}
                                </p>
                              @enderror
                        </div>
                        <div class="form-group mt-2">
                    
                              <input type="submit" name="submit" value="SUBMIT" class="form-control bg-success text-white">
                        </div>
                    </form>
                
                </div>
                <div class="col-md-4 mt-4">
                  <table class="table table-striped">
                              <tr>
                                <th>FirstName</th>
                                <th>LastName</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Action</th>
                              </tr>
                              @foreach($students as $student)
                              <tr>
                                <td>{{$student->firstname}}</td>
                                <td>{{$student->lastname}}</td>
                                <td>{{$student->username}}</td>
                                <td>{{$student->email}}</td>
                                <td>{{$student->password}}</td>
                                <td class="d-flex">
                                  <a href="{{url('edit',$student->id)}}" class="btn btn-success">Edit</a>
                                  <a href="{{url('delete',$student->id)}}" class="btn btn-danger">Delete</a>
                                </td>
                              </tr>
                              @endforeach

                            
                  </table>
                </div>
            </div>
      </div>
</body>
</html>