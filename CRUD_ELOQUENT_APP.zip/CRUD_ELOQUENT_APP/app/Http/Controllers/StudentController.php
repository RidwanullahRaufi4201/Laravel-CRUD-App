<?php

namespace App\Http\Controllers;

use App\Models\student;

use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index()
    { 
         $student=new student;
         $students=$student::get();
        return view('CRUD',['students'=>$students]);
    }

    public function create(Request $req)
    {
          
            $student=new student;
            $validate=$req->validate([
                'firstname'=>['required','min:3'],
                'lastname'=>['required','min:3'],
                'username'=>['required','min:6'],
                'email'=>'required',
                'password'=>['required','min:5'],
            ]);

            $student->firstname=$req->firstname;
            $student->lastname=$req->lastname;
            $student->username=$req->username;
            $student->email=$req->email;
            $student->password=$req->password;
            $student->save();
        
           return redirect(route('index'))->with('status','record inserted successfully!');

    }


    public function edit($id)
    {
           $student=new student;
           $stud=$student::find($id);
           return view('edit',['student'=>$stud]);
    }


    public function update(Request $req,$id)
    {
           $validate=$req->validate([
            'firstname'=>['required','min:3'],
            'lastname'=>['required','min:3'],
            'username'=>['required','min:6'],
            'email'=>'required',
            'password'=>'min:5'
           ]);

        $student =student::find($id);
    
        
        $student->firstname=$req->firstname;
        $student->lastname=$req->lastname;
        $student->username=$req->username;
        $student->email=$req->email;
        $student->password=$req->password;
        $student->save();
        return redirect(route('index'))->with('status','record updated successfully !');


    }



    public function delete($id)
    {
          student::destroy($id);
          return redirect(route('index'))->with('status','record deleted successfully!');
    }

}
